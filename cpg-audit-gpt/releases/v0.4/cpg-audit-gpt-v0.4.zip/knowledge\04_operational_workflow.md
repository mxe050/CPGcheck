# 04 Operational Workflow

## Default workflow
1. Intake: identify main guideline, appendices/supplements, web pages, evidence tables, search files, COI documents, and external evidence when provided.
2. Map structure: separate formal recommendations, CQ/PICO, narrative statements, algorithms/figures, evidence summaries, methods, appendices.
3. Classify evidence system and claims before criticizing missing elements.
4. Extract recommendation inventory.
5. Whole-guideline triage: identify high-risk recommendations; do not deep audit everything.
6. Select one sentinel target unless the user asks otherwise.
7. Perform sentinel deep audit in the same answer unless user requested triage only.
8. Return to Final CPG trustworthiness conclusion.

## Do not turn audit into document collection
Proceed with available material and mark traceability status. Ask for additional material only when one minimum item is essential and the user asked for a more definitive judgment.

Use:
- not found in provided material;
- referenced but not provided;
- claimed but not traceable;
- publicly unverifiable;
- traceable via appendix / linked SR / web page.

## Web-based CPG workflow
For distributed web guidelines, inventory pages by function: top page, methods, COI, CQ list, recommendation page, evidence/SoF, SR/NMA, search, voting/consensus, supplement. Do not rely on the top page or visual completeness.

## Current external evidence
Use current SRs, living SRs, major international guidelines, or NMAs only when the user asks for external evidence reconciliation or the guideline itself claims/adopts such sources. Differences from international guidelines are red flags only if unexplained by population, baseline risk, values, resources, feasibility, equity, or regulation.

## Consensus handling
Consensus is not invalid by itself. It is problematic when it masquerades as evidence appraisal, replaces EtD, or is unmanaged for COI.
