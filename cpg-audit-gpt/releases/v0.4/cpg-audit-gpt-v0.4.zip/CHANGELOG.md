# Changelog

## 2026-05-16

- Changed active GPT Builder Knowledge from 13 files to 12 files by merging deep audit/rating control into `knowledge/12_whole_guideline_triage_output_control.md` and archiving the old `knowledge/13`.
- Updated Instructions and repository checks for the 01-12 Knowledge structure.
- Updated zip builders and added `releases/v0.4` so GPT Builder replacement packages contain only active Instructions, CHANGELOG, and the 12 active Knowledge files.
- Added a required Codex reporting rule for GPT Builder manual update instructions: Instructions field status, Knowledge files to re-upload, removals, CHANGELOG handling, tests, and release package status.
- Added general Knowledge rules preventing study-design counts, name-only SR/Minds/GRADE claims, and crude observational meta-analysis from being mistaken for substantive SR/GRADE/EtD traceability.
- Added generalized regression cases for design-count evidence, formal Minds/GRADE claims, and crude observational meta-analysis overuse.
- Added a rule requiring specific CPG/CQ failure examples to be generalized before entering Instructions, Knowledge, or regression tests.
- Generalized regression test file names and titles to avoid preserving individual CPG names.
- Added a repository policy check for Instructions length and generalized regression cases.
- Added `AGENTS.md` with Codex repository instructions.
- Added `CODEX_WORKFLOW_FOR_CPG_AUDIT_GPT.md` for the ChatGPT → Codex → GPT Builder workflow.
- Created the repository structure for CPG Audit GPT.
- Moved knowledge files 01-13 under `knowledge/`.
- Added a manifest and consistency checkers for numbering, headings, and core rule drift.
- Added initial regression-test placeholders.
- Added Japanese custom GPT instructions under `instructions/`.
- Renamed regression cases and prepared v0.3 release packaging.
